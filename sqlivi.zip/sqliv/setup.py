#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from colorama import Fore, Back, Style, init
init(autoreset=True)


class Color:
    RED = Fore.RED
    GREEN = Fore.GREEN
    YELLOW = Fore.YELLOW
    CYAN = Fore.CYAN
    MAGENTA = Fore.MAGENTA
    RESET = Fore.RESET

class Style:
    BRIGHT = Style.BRIGHT
    NORMAL = Style.NORMAL

import argparse
import os
import stat
import sys
import subprocess
from shutil import copy2, rmtree, copytree
from distutils.dir_util import copy_tree
from pathlib import Path

__author__ = "Ghost"
__email__ = "official.ghost@tuta.io"
__license__ = "GPL"
__version__ = "3.0"

# Installation directory PATHS
FILE_PATH_LINUX = "/usr/share/sqliv"
EXEC_PATH_LINUX = "/usr/bin/sqliv"

FILE_PATH_MAC = "/usr/local/share/sqliv"
EXEC_PATH_MAC = "/usr/local/bin/sqliv"

# Colors using colorma
try:
except ImportError:
    class Color:
        RED = GREEN = YELLOW = CYAN = MAGENTA = RESET = ""
    class Style:
        BRIGHT = ""

def metadata():
    print(f"{Color.GREEN}SQLiv v{__version__} by {__author__}{Color.RESET}")
    print(f"{Color.YELLOW}Massive SQL injection vulnerability scanner{Color.RESET}")

def install_dependencies(option):
    """Install/uninstall script dependencies with pip3"""
    try:
        req_file = Path("requirements.txt")
        if not req_file.exists():
            print(f"{Color.RED}[-] requirements.txt not found{Color.RESET}")
            sys.exit(1)
        
        with open(req_file, "r") as requirements:
            dependencies = [line.strip() for line in requirements if line.strip() and not line.startswith('#')]
        
        if not dependencies:
            print(f"{Color.YELLOW}[!] No dependencies found in requirements.txt{Color.RESET}")
            return
        
        print(f"{Color.CYAN}[*] {option}ing dependencies...{Color.RESET}")
        for lib in dependencies:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", option, lib])
                print(f"{Color.GREEN}[+] Installed: {lib}{Color.RESET}")
            except subprocess.CalledProcessError:
                print(f"{Color.RED}[-] Failed to install: {lib}{Color.RESET}")
                
    except Exception as e:
        print(f"{Color.RED}[-] Error installing dependencies: {e}{Color.RESET}")

def install(file_path, exec_path):
    """Full installation of SQLiv to the system"""
    try:
        # Create main directory
        os.makedirs(file_path, exist_ok=True)
        
        # Copy main files
        for file in ["sqliv.py", "requirements.txt", "LICENSE", "README.md"]:
            src = Path(file)
            if src.exists():
                copy2(str(src), file_path)
                print(f"{Color.GREEN}[+] Copied: {file}{Color.RESET}")
        
        # Copy src directory
        src_dir = Path("src")
        if src_dir.exists():
            dest_dir = Path(file_path) / "src"
            if dest_dir.exists():
                rmtree(str(dest_dir))
            copytree(str(src_dir), str(dest_dir))
            print(f"{Color.GREEN}[+] Copied: src/{Color.RESET}")
        
        # Copy lib directory
        lib_dir = Path("lib")
        if lib_dir.exists():
            dest_dir = Path(file_path) / "lib"
            if dest_dir.exists():
                rmtree(str(dest_dir))
            copytree(str(lib_dir), str(dest_dir))
            print(f"{Color.GREEN}[+] Copied: lib/{Color.RESET}")
        
        # Copy screenshots if exists
        screenshots_dir = Path("screenshots")
        if screenshots_dir.exists():
            dest_dir = Path(file_path) / "screenshots"
            if dest_dir.exists():
                rmtree(str(dest_dir))
            copytree(str(screenshots_dir), str(dest_dir))
            print(f"{Color.GREEN}[+] Copied: screenshots/{Color.RESET}")
        
        # Install Python dependencies
        install_dependencies("install")
        
        # Create executable
        with open(exec_path, 'w') as installer:
            installer.write('#!/bin/bash\n')
            installer.write(f'\n')
            installer.write(f'python3 {file_path}/sqliv.py "$@"\n')
        
        # Set executable permissions
        os.chmod(exec_path, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
        print(f"{Color.GREEN}[+] Created executable: {exec_path}{Color.RESET}")
        
    except Exception as e:
        print(f"{Color.RED}[-] Installation failed: {e}{Color.RESET}")
        sys.exit(1)

def uninstall(file_path, exec_path):
    """Uninstall sqliv from the system"""
    try:
        if Path(file_path).exists():
            rmtree(file_path)
            print(f"{Color.GREEN}[+] Removed: {file_path}{Color.RESET}")
        
        if Path(exec_path).is_file():
            os.remove(exec_path)
            print(f"{Color.GREEN}[+] Removed: {exec_path}{Color.RESET}")
            
    except Exception as e:
        print(f"{Color.RED}[-] Uninstallation failed: {e}{Color.RESET}")

def main():
    parser = argparse.ArgumentParser(
        description="SQLiv Installation Script v3.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
{Color.YELLOW}Examples:{Color.RESET}
  {Color.GREEN}sudo python3 setup.py -i{Color.RESET}       Install SQLiv
  {Color.GREEN}sudo python3 setup.py -r{Color.RESET}      Reinstall SQLiv
  {Color.GREEN}sudo python3 setup.py -u{Color.RESET}      Uninstall SQLiv
        """
    )
    parser.add_argument("-i", "--install", help="Install SQLiv on the system", action='store_true')
    parser.add_argument("-r", "--reinstall", help="Remove old files and reinstall", action="store_true")
    parser.add_argument("-u", "--uninstall", help="Uninstall SQLiv from the system", action="store_true")
    args = parser.parse_args()

    # Detect platform
    if sys.platform.startswith('linux'):
        FILE_PATH = FILE_PATH_LINUX
        EXEC_PATH = EXEC_PATH_LINUX
        if os.getuid() != 0:
            print(f"{Color.RED}[-] Linux requires root access for installation{Color.RESET}")
            sys.exit(1)
            
    elif sys.platform == 'darwin':
        FILE_PATH = FILE_PATH_MAC
        EXEC_PATH = EXEC_PATH_MAC
        if os.getuid() != 0:
            print(f"{Color.YELLOW}[!] macOS may require sudo for system-wide installation{Color.RESET}")
            
    else:
        print(f"{Color.RED}[-] Windows not supported for system installation{Color.RESET}")
        print(f"{Color.YELLOW}[!] You can run directly: python3 sqliv.py --help{Color.RESET}")
        sys.exit(1)

    if args.install and not (args.reinstall or args.uninstall):
        if Path(FILE_PATH).exists() or Path(EXEC_PATH).is_file():
            print(f"{Color.YELLOW}[!] SQLiv is already installed{Color.RESET}")
            print(f"{Color.CYAN}[*] Use -r to reinstall or -u to uninstall{Color.RESET}")
            sys.exit(1)
            
        print(f"{Color.CYAN}[*] Installing SQLiv...{Color.RESET}")
        install(FILE_PATH, EXEC_PATH)
        print(f"\n{Color.GREEN}[+] Installation finished successfully!{Color.RESET}")
        print(f"{Color.CYAN}[*] Files installed at: {FILE_PATH}{Color.RESET}")
        print(f"{Color.GREEN}[+] Run: sqliv --help{Color.RESET}")

    elif args.uninstall and not (args.install or args.reinstall):
        print(f"{Color.CYAN}[*] Uninstalling SQLiv...{Color.RESET}")
        uninstall(FILE_PATH, EXEC_PATH)
        
        option = input(f"{Color.YELLOW}Do you want to uninstall Python dependencies? [Y/N]: {Color.RESET}").upper()
        while option not in ["Y", "N"]:
            option = input(f"{Color.YELLOW}Invalid option. [Y/N]: {Color.RESET}").upper()
            
        if option == "Y":
            install_dependencies("uninstall")
            print(f"{Color.GREEN}[+] Dependencies removed{Color.RESET}")
            
        print(f"{Color.GREEN}[+] Uninstallation finished!{Color.RESET}")

    elif args.reinstall and not (args.install or args.uninstall):
        print(f"{Color.CYAN}[*] Reinstalling SQLiv...{Color.RESET}")
        uninstall(FILE_PATH, EXEC_PATH)
        print(f"{Color.GREEN}[+] Removed previous installation{Color.RESET}")
        
        install(FILE_PATH, EXEC_PATH)
        print(f"\n{Color.GREEN}[+] Reinstallation finished successfully!{Color.RESET}")
        print(f"{Color.CYAN}[*] Files installed at: {FILE_PATH}{Color.RESET}")
        print(f"{Color.GREEN}[+] Run: sqliv --help{Color.RESET}")

    else:
        metadata()
        print("")
        parser.print_help()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Color.YELLOW}[!] Installation cancelled{Color.RESET}")
        sys.exit(1)
    except Exception as e:
        print(f"{Color.RED}[-] Error: {e}{Color.RESET}")
        sys.exit(1)