#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re

files_to_fix = [
    'sqliv.py',
    'setup.py',
    'src/std.py'
]

for file_path in files_to_fix:
    if not os.path.exists(file_path):
        print(f"[!] File not found: {file_path}")
        continue
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.splitlines()
    new_lines = []
    skip_next = False
    import_added = False
    
    for i, line in enumerate(lines):
        if 'from colorma import Color, Style' in line:
            continue
        
        if 'from colorma' in line:
            continue
        
        if 'import colorma' in line:
            continue
        
        if 'colorma' in line and 'Color' in line and 'Style' in line:
            continue
        
        new_lines.append(line)
    
    content = '\n'.join(new_lines)
    
    if 'from colorama import Fore, Back, Style, init' not in content:
        lines = content.splitlines()
        new_lines = []
        colorama_added = False
        
        for i, line in enumerate(lines):
            if not colorama_added and line.strip().startswith('import ') and not line.strip().startswith('from'):
                new_lines.append('from colorama import Fore, Back, Style, init')
                new_lines.append('init(autoreset=True)')
                new_lines.append('')
                new_lines.append('')
                new_lines.append('class Color:')
                new_lines.append('    RED = Fore.RED')
                new_lines.append('    GREEN = Fore.GREEN')
                new_lines.append('    YELLOW = Fore.YELLOW')
                new_lines.append('    CYAN = Fore.CYAN')
                new_lines.append('    MAGENTA = Fore.MAGENTA')
                new_lines.append('    RESET = Fore.RESET')
                new_lines.append('')
                new_lines.append('class Style:')
                new_lines.append('    BRIGHT = Style.BRIGHT')
                new_lines.append('    NORMAL = Style.NORMAL')
                new_lines.append('')
                colorama_added = True
            
            new_lines.append(line)
        
        if not colorama_added:
            new_lines.insert(0, 'from colorama import Fore, Back, Style, init')
            new_lines.insert(1, 'init(autoreset=True)')
            new_lines.insert(2, '')
            new_lines.insert(3, '')
            new_lines.insert(4, 'class Color:')
            new_lines.insert(5, '    RED = Fore.RED')
            new_lines.insert(6, '    GREEN = Fore.GREEN')
            new_lines.insert(7, '    YELLOW = Fore.YELLOW')
            new_lines.insert(8, '    CYAN = Fore.CYAN')
            new_lines.insert(9, '    MAGENTA = Fore.MAGENTA')
            new_lines.insert(10, '    RESET = Fore.RESET')
            new_lines.insert(11, '')
            new_lines.insert(12, 'class Style:')
            new_lines.insert(13, '    BRIGHT = Style.BRIGHT')
            new_lines.insert(14, '    NORMAL = Style.NORMAL')
            new_lines.insert(15, '')
        
        content = '\n'.join(new_lines)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"[+] Fixed: {file_path}")

print("[✓] All files updated successfully!")
print("[*] Run: pip install colorama")
