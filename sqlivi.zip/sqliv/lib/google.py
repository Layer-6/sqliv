#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time
import random
from typing import Generator, Optional, Dict, List, Set
from urllib.parse import quote_plus, urlparse, parse_qs, urlencode
from http.cookiejar import LWPCookieJar
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

try:
    from bs4 import BeautifulSoup
except ImportError:
    raise ImportError("BeautifulSoup4 is required. Install with: pip install beautifulsoup4")

class Google:
    def __init__(self):
        self.tld = 'com'
        self.lang = 'en'
        self.safe = 'off'
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0'
        ]
        
        home_folder = os.getenv('HOME') or os.getenv('USERHOME') or '.'
        self.cookie_jar = LWPCookieJar(os.path.join(home_folder, '.google-cookie'))
        try:
            self.cookie_jar.load()
        except:
            pass

    def get_page(self, url: str) -> str:
        """Fetch page with cookie handling and retry"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                request = Request(url)
                request.add_header('User-Agent', random.choice(self.user_agents))
                request.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
                request.add_header('Accept-Language', 'en-US,en;q=0.9')
                
                self.cookie_jar.add_cookie_header(request)
                response = urlopen(request, timeout=15)
                self.cookie_jar.extract_cookies(response, request)
                html = response.read().decode('utf-8', errors='ignore')
                response.close()
                self.cookie_jar.save()
                return html
                
            except (URLError, HTTPError, TimeoutError) as e:
                if attempt < max_retries - 1:
                    time.sleep(random.uniform(2, 5))
                    continue
                raise

    def filter_result(self, link: str) -> Optional[str]:
        """Filter and clean Google search results"""
        try:
            o = urlparse(link, 'http')
            if o.netloc and 'google' not in o.netloc:
                return link

            if link.startswith('/url?'):
                parsed = parse_qs(o.query)
                if 'q' in parsed:
                    link = parsed['q'][0]
                    o = urlparse(link, 'http')
                    if o.netloc and 'google' not in o.netloc:
                        return link
        except:
            pass
        return None

    def search(self, query: str, stop: int = 100, tld: str = 'com', lang: str = 'en', 
               tbs: str = '0', safe: str = 'off', num: int = 10, 
               pause: float = 2.0, tpe: str = '') -> List[str]:
        """Main search method"""
        self.tld = tld
        self.lang = lang
        self.safe = safe
        
        query = quote_plus(query)
        hashes = set()
        results = []
        start = 0
        
        try:
            self.get_page(f"https://www.google.{tld}/")
        except:
            pass

        while len(results) < stop:
            if start == 0:
                url = f"https://www.google.{tld}/search?hl={lang}&q={query}&btnG=Google+Search&tbs={tbs}&safe={safe}&tbm={tpe}"
                if num != 10:
                    url += f"&num={num}"
            else:
                url = f"https://www.google.{tld}/search?hl={lang}&q={query}&start={start}&tbs={tbs}&safe={safe}&tbm={tpe}"
                if num != 10:
                    url += f"&num={num}"

            time.sleep(pause + random.uniform(0, 0.5))
            
            try:
                html = self.get_page(url)
                soup = BeautifulSoup(html, 'html.parser')
                
                search_div = soup.find('div', {'id': 'search'})
                if not search_div:
                    break
                    
                anchors = search_div.find_all('a')
                for a in anchors:
                    link = a.get('href')
                    if not link:
                        continue
                        
                    link = self.filter_result(link)
                    if not link:
                        continue
                        
                    h = hash(link)
                    if h in hashes:
                        continue
                    hashes.add(h)
                    results.append(link)
                    
                    if len(results) >= stop:
                        return results[:stop]
                
                if not soup.find('div', {'id': 'nav'}):
                    break
                    
                start += num
                
            except:
                break
                
        return results

    def search_images(self, query: str, stop: int = 50) -> List[str]:
        """Search for images"""
        return self.search(query, stop, tpe='isch')

    def search_news(self, query: str, stop: int = 50) -> List[str]:
        """Search for news"""
        return self.search(query, stop, tpe='nws')

    def search_videos(self, query: str, stop: int = 50) -> List[str]:
        """Search for videos"""
        return self.search(query, stop, tpe='vid')

    def lucky(self, query: str) -> Optional[str]:
        """Get first result"""
        results = self.search(query, stop=1, pause=0)
        return results[0] if results else None
