#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import urllib.request
import urllib.error
import urllib.parse
import time
import random
from typing import List, Dict, Optional
from urllib.parse import quote_plus

class Bing:
    def __init__(self):
        self.bingsearch = "https://www.bing.com/search?%s"
        self.regex = re.compile(r'<h2><a href="(.*?)"')
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15'
        ]

    def default_headers(self) -> Dict[str, str]:
        return {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'User-Agent': random.choice(self.user_agents),
            'Referer': 'https://www.bing.com/',
            'DNT': '1'
        }

    def get_page(self, URL: str) -> Optional[str]:
        """Fetch page with retry mechanism"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(URL, headers=self.default_headers())
                with urllib.request.urlopen(request, timeout=15) as resp:
                    content = resp.read().decode('utf-8', errors='ignore')
                    return content
            except (urllib.error.URLError, TimeoutError, ConnectionError):
                if attempt < max_retries - 1:
                    wait = random.uniform(2, 5)
                    time.sleep(wait)
                    continue
                return None
        return None

    def parse_links(self, html: str) -> List[str]:
        """Extract URLs with improved regex"""
        if not html:
            return []
        
        # Multiple regex patterns for different Bing formats
        patterns = [
            r'<h2><a href="([^"]+)"',
            r'<a href="([^"]+)"[^>]*>.*?<h2',
            r'<cite[^>]*>([^<]+)</cite>'
        ]
        
        links = []
        for pattern in patterns:
            matches = re.findall(pattern, html)
            for match in matches:
                if match.startswith('http') and match not in links:
                    # Clean up URLs
                    cleaned = re.sub(r'[<>"\'`]', '', match)
                    if cleaned and 'bing.com' not in cleaned and 'microsoft.com' not in cleaned:
                        links.append(cleaned)
        
        return links

    def search(self, query: str, stop: int = 100) -> List[str]:
        """Enhanced search with better pagination"""
        links = []
        seen = set()
        
        # Clean query
        query = query.strip()
        if not query:
            return []
        
        # Calculate pages
        pages = min((stop // 10) + 1, 50)  # Limit to 50 pages
        
        for page in range(pages):
            start = (page * 10) + 1
            
            # Build URL
            params = {
                'q': query,
                'first': str(start),
                'count': '10',
                'setlang': 'en-US',
                'FORM': 'PERE'
            }
            
            URL = self.bingsearch % urllib.parse.urlencode(params)
            
            try:
                html = self.get_page(URL)
                if not html:
                    continue
                
                results = self.parse_links(html)
                for link in results:
                    if link not in seen:
                        seen.add(link)
                        links.append(link)
                        
                    if len(links) >= stop:
                        return links[:stop]
                
                # Check if we're at the last page
                if 'No results' in html or 'did not match' in html:
                    break
                    
                # Random delay to avoid rate limiting
                if len(links) < stop:
                    delay = random.uniform(0.5, 2.0)
                    time.sleep(delay)
                    
            except Exception:
                continue
        
        return links[:stop]

    def search_advanced(self, query: str, stop: int = 100, filters: Optional[List[str]] = None) -> List[str]:
        """Advanced search with filters"""
        if filters:
            query = f"{query} {' '.join(filters)}"
        return self.search(query, stop)

    def get_count(self, query: str) -> int:
        """Get estimated result count"""
        try:
            URL = self.bingsearch % urllib.parse.urlencode({'q': query})
            html = self.get_page(URL)
            if html:
                match = re.search(r'([0-9,]+) results', html)
                if match:
                    count = match.group(1).replace(',', '')
                    return int(count)
        except:
            pass
        return 0
