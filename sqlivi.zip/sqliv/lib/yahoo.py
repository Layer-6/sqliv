#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import urllib.request
import urllib.error
import urllib.parse
import time
import random
from typing import List, Optional
from bs4 import BeautifulSoup

class Yahoo:
    def __init__(self):
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15'
        ]
        self.accept_headers = [
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
        ]

    def get_page(self, url: str) -> Optional[str]:
        """Fetch page with retry mechanism"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                request = urllib.request.Request(url)
                request.add_header('User-Agent', random.choice(self.user_agents))
                request.add_header('Accept', random.choice(self.accept_headers))
                request.add_header('Accept-Language', 'en-US,en;q=0.9')
                request.add_header('Accept-Encoding', 'gzip, deflate, br')
                request.add_header('Connection', 'keep-alive')
                request.add_header('Referer', 'https://search.yahoo.com/')
                request.add_header('DNT', '1')
                
                with urllib.request.urlopen(request, timeout=15) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                    return content
                    
            except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
                if attempt < max_retries - 1:
                    time.sleep(random.uniform(2, 5))
                    continue
                return None
        return None

    def parse_links(self, html: str) -> List[str]:
        """Extract URLs from Yahoo search results"""
        if not html:
            return []
            
        links = []
        seen = set()
        
        try:
            soup = BeautifulSoup(html, 'html.parser')
            
            patterns = [
                'a.ac-algo.fz-l.ac-21th.lh-24',
                'a[class*="ac-algo"]',
                'div.compTitle a',
                'h3.title a',
                'div[class*="title"] a'
            ]
            
            for pattern in patterns:
                try:
                    for element in soup.select(pattern):
                        href = element.get('href')
                        if href and href not in seen:
                            if href.startswith('/'):
                                href = 'https://search.yahoo.com' + href
                            if 'yahoo.com' not in href and 'yimg.com' not in href:
                                seen.add(href)
                                links.append(href)
                except:
                    continue
                    
            if not links:
                for link in soup.find_all('a'):
                    href = link.get('href')
                    if href and href.startswith('http') and 'yahoo' not in href:
                        if href not in seen:
                            seen.add(href)
                            links.append(href)
                            
        except:
            pass
            
        return links

    def search(self, query: str, per_page: int = 10, pages: int = 1) -> List[str]:
        """Search URLs from Yahoo with pagination"""
        if not query:
            return []
            
        all_links = []
        seen = set()
        query_encoded = urllib.parse.quote_plus(query)
        
        max_pages = min(pages, 20)
        
        for page in range(max_pages):
            start = (page * per_page) + 1
            
            url = f"https://search.yahoo.com/search?p={query_encoded}&n={per_page}&b={start}"
            
            try:
                html = self.get_page(url)
                if not html:
                    continue
                    
                links = self.parse_links(html)
                
                for link in links:
                    if link not in seen:
                        seen.add(link)
                        all_links.append(link)
                        
                if not links or 'no results' in html.lower():
                    break
                    
                if page < max_pages - 1:
                    time.sleep(random.uniform(0.5, 2.0))
                    
            except:
                continue
                
        return all_links

    def search_advanced(self, query: str, per_page: int = 10, pages: int = 1, 
                       filters: Optional[List[str]] = None) -> List[str]:
        """Advanced search with filters"""
        if filters:
            query = f"{query} {' '.join(filters)}"
        return self.search(query, per_page, pages)

    def get_count(self, query: str) -> int:
        """Get estimated result count"""
        try:
            query_encoded = urllib.parse.quote_plus(query)
            url = f"https://search.yahoo.com/search?p={query_encoded}&n=1"
            html = self.get_page(url)
            
            if html:
                soup = BeautifulSoup(html, 'html.parser')
                count_elem = soup.find('span', {'class': 'count'})
                if count_elem:
                    count_text = count_elem.text.replace(',', '')
                    import re
                    numbers = re.findall(r'\d+', count_text)
                    if numbers:
                        return int(numbers[0])
        except:
            pass
        return 0
