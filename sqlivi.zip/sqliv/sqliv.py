#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from colorama import Fore, Back, Style, init
init(autoreset=True)


class Color:
    RED = Fore.RED
    GREEN = Fore.GREEN
    YELLOW = Fore.YELLOW
    CYAN = Fore.CYAN
    MAGENTA = Fore.MAGENTA
    RESET = Fore.RESET

class Style:
    BRIGHT = Style.BRIGHT
    NORMAL = Style.NORMAL

import argparse
import sys
import json
from urllib.parse import urlparse
from datetime import datetime

from src import std
from src import scanner
from src import reverseip
from src import serverinfo
from src.web import search
from src.crawler import Crawler

LOGO = f"""
{Color.RED}                   ████   ███
                  ░░███  ░░░
  █████   ████████ ░███  ████  █████ █████
 ███░░   ███░░███  ░███ ░░███ ░░███ ░░███
░░█████ ░███ ░███  ░███  ░███  ░███  ░███
 ░░░░███░███ ░███  ░███  ░███  ░░███ ███
 ██████ ░░███████  █████ █████  ░░█████
░░░░░░   ░░░░░███ ░░░░░ ░░░░░    ░░░░░
             ░███
             █████
            ░░░░░{Color.RESET}

{Color.YELLOW}        SQLiv v3.0 -  SQL Injection Scanner{Color.RESET}
{Color.RED}          t.me/Red_Rooted_Ghost {Color.RESET}
{Color.YELLOW}        {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Color.RESET}
{Style.BRIGHT}{Color.GREEN}        {'='*50}{Color.RESET}
"""

bing = search.Bing()
google = search.Google()
yahoo = search.Yahoo()

SEARCH_ENGINES = {
    "bing": bing,
    "google": google,
    "yahoo": yahoo
}

crawler = Crawler()

def singlescan(url):
    """Enhanced single target scan with progress indication"""
    if urlparse(url).query != '':
        print(f"{Color.CYAN}[*] Testing parameters on: {url}{Color.RESET}")
        result = scanner.scan([url])
        if result:
            return result
        
        print(f"{Color.YELLOW}[!] No direct injection found{Color.RESET}")
        option = std.stdin(
            "do you want to crawl and continue scanning? [Y/N]",
            ["Y", "N"],
            upper=True
        )
        if option == 'N':
            return False

    print(f"{Color.CYAN}[*] Crawling: {url}{Color.RESET}")
    urls = crawler.crawl(url)

    if not urls:
        print(f"{Color.RED}[-] No suitable URLs found{Color.RESET}")
        return False

    print(f"{Color.GREEN}[+] Found {len(urls)} URLs from crawling{Color.RESET}")
    vulnerables = scanner.scan(urls)

    if not vulnerables:
        print(f"{Color.RED}[-] No SQL injection vulnerability found{Color.RESET}")
        return False

    return vulnerables

def initparser():
    parser = argparse.ArgumentParser(
        description="SQLiv - Advanced SQL Injection Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
{Color.YELLOW}Examples:{Color.RESET}
  {Color.GREEN}python sqliv.py -d "inurl:index.php?id=" -e google -p 50{Color.RESET}
  {Color.GREEN}python sqliv.py -t example.com -o result.json{Color.RESET}
  {Color.GREEN}python sqliv.py -t example.com -r --level 3{Color.RESET}
        """
    )
    parser.add_argument(
        "-d", "--dork",
        help="SQL injection dork (e.g., inurl:example)",
        type=str, metavar="inurl:example"
    )
    parser.add_argument(
        "-e", "--engine",
        help="search engine: bing, google, yahoo",
        type=str, metavar="bing|google|yahoo"
    )
    parser.add_argument(
        "-p", "--page",
        help="number of websites to fetch",
        type=int, default=10, metavar="100"
    )
    parser.add_argument(
        "-t", "--target",
        help="target website to scan",
        type=str, metavar="www.example.com"
    )
    parser.add_argument(
        '-r', "--reverse",
        help="perform reverse IP lookup",
        action='store_true'
    )
    parser.add_argument(
        '-o', "--output",
        help="save result as JSON file",
        type=str, metavar="result.json"
    )
    parser.add_argument(
        '--level',
        help="scan level (1-3, higher = more thorough)",
        type=int, choices=[1, 2, 3], default=2
    )
    parser.add_argument(
        '--threads',
        help="number of threads",
        type=int, default=10
    )
    parser.add_argument(
        '-s', action='store_true',
        help="save search results even if no vulnerabilities found"
    )
    parser.add_argument(
        '--no-color',
        action='store_true',
        help="disable colored output"
    )
    return parser

def main():
    print(LOGO)
    
    parser = initparser()
    args = parser.parse_args()
    
    if args.no_color:
        Color.RESET = Color.RED = Color.GREEN = Color.YELLOW = Color.CYAN = ""
        Style.BRIGHT = ""

    if args.dork and args.engine:
        print(f"{Color.CYAN}[*] Searching with dork: {args.dork}{Color.RESET}")
        
        if args.engine.lower() not in SEARCH_ENGINES:
            print(f"{Color.RED}[-] Invalid search engine: {args.engine}{Color.RESET}")
            sys.exit(1)

        engine = SEARCH_ENGINES[args.engine.lower()]
        websites = engine.search(args.dork, args.page)
        print(f"{Color.GREEN}[+] {len(websites)} websites found{Color.RESET}")

        vulnerables = scanner.scan(websites, threads=args.threads, level=args.level)

        if not vulnerables:
            if args.s:
                print(f"{Color.YELLOW}[!] Saved as searches.txt{Color.RESET}")
                std.dump(websites, "searches.txt")
            sys.exit(0)

        print(f"{Color.CYAN}[*] Scanning server information{Color.RESET}")
        vulnerable_urls = [result[0] for result in vulnerables]
        table_data = serverinfo.check(vulnerable_urls)

        for result, info in zip(vulnerables, table_data):
            info.insert(1, result[1])

        std.fullprint(table_data)

    elif args.target and args.reverse:
        print(f"{Color.CYAN}[*] Finding domains on same server as {args.target}{Color.RESET}")
        domains = reverseip.reverseip(args.target)

        if not domains:
            print(f"{Color.RED}[-] No domains found{Color.RESET}")
            sys.exit(0)

        print(f"{Color.GREEN}[+] Found {len(domains)} domains{Color.RESET}")
        
        option = std.stdin(
            "save domains to file? [Y/N]",
            ["Y", "N"],
            upper=True
        )
        if option == 'Y':
            print(f"{Color.GREEN}[+] Saved as domains.txt{Color.RESET}")
            std.dump(domains, "domains.txt")

        option = std.stdin(
            "start crawling? [Y/N]",
            ["Y", "N"],
            upper=True
        )
        if option == 'N':
            sys.exit(0)

        vulnerables = []
        total = len(domains)
        for i, domain in enumerate(domains, 1):
            print(f"{Color.CYAN}[*] Processing {i}/{total}: {domain}{Color.RESET}")
            result = singlescan(domain)
            if result:
                vulnerables.extend(result)

        print(f"{Color.GREEN}[+] Finished scanning all reverse domains{Color.RESET}")
        if not vulnerables:
            print(f"{Color.RED}[-] No vulnerable websites found{Color.RESET}")
            sys.exit(0)

        print(f"{Color.CYAN}[*] Scanning server information{Color.RESET}")
        vulnerable_urls = [result[0] for result in vulnerables]
        table_data = serverinfo.check(vulnerable_urls)

        for result, info in zip(vulnerables, table_data):
            info.insert(1, result[1])

        std.fullprint(table_data)

    elif args.target:
        vulnerables = singlescan(args.target)

        if not vulnerables:
            sys.exit(0)

        print(f"{Color.CYAN}[*] Getting server information...{Color.RESET}")
        table_data = serverinfo.check([args.target])

        std.printserverinfo(table_data)
        print("")
        std.normalprint(vulnerables)

    else:
        parser.print_help()

    if args.output:
        try:
            if 'table_data' in locals():
                output_data = {
                    "timestamp": datetime.now().isoformat(),
                    "target": args.target or args.dork,
                    "results": table_data
                }
                with open(args.output, 'w', encoding='utf-8') as f:
                    json.dump(output_data, f, indent=2, ensure_ascii=False)
                print(f"{Color.GREEN}[+] Results saved to {args.output}{Color.RESET}")
        except NameError:
            print(f"{Color.RED}[-] No data to dump{Color.RESET}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Color.YELLOW}[!] Scan interrupted by user{Color.RESET}")
        sys.exit(1)
    except Exception as e:
        print(f"{Color.RED}[-] Error: {e}{Color.RESET}")
        sys.exit(1)
