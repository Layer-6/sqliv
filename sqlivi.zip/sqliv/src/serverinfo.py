#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import signal
import multiprocessing
from urllib.parse import urlparse
from typing import List, Tuple, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

from bs4 import BeautifulSoup
from src import std
from src.web import web


def init():
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def check(urls: List[str], threads: int = 10) -> List[List[str]]:
    if not urls:
        return []
    
    domains_info = []
    max_processes = min(multiprocessing.cpu_count() * 2, threads)
    pool = multiprocessing.Pool(max_processes, init)
    
    childs = []
    for url in urls:
        child = pool.apply_async(__getserverinfo, (url,))
        childs.append(child)
    
    try:
        while True:
            time.sleep(0.5)
            if all(child.ready() for child in childs):
                break
    except KeyboardInterrupt:
        std.stderr("skipping server info scanning process")
        pool.terminate()
        pool.join()
        return [[url, '', ''] for url in urls]
    
    pool.close()
    pool.join()
    
    for child, url in zip(childs, urls):
        try:
            data = child.get(timeout=1)
            if data and len(data) == 2:
                domains_info.append([url, data[0], data[1]])
            else:
                domains_info.append([url, '', ''])
        except Exception:
            domains_info.append([url, '', ''])
    
    return domains_info


def check_parallel(urls: List[str], threads: int = 20) -> List[List[str]]:
    results = []
    
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(__getserverinfo_thread, url): url for url in urls}
        
        for future in as_completed(futures):
            try:
                url = futures[future]
                data = future.result(timeout=10)
                if data and len(data) == 2:
                    results.append([url, data[0], data[1]])
                else:
                    results.append([url, '', ''])
            except:
                results.append([url, '', ''])
    
    return results


def __getserverinfo(url: str) -> Tuple[str, str]:
    parsed = urlparse(url)
    domain = parsed.netloc if parsed.netloc else parsed.path.split("/")[0]
    
    if not domain:
        return '', ''
    
    target_url = f"https://aruljohn.com/webserver/{domain}"
    server = ''
    version = ''
    
    try:
        result = web.gethtml(target_url)
        if not result:
            return '', ''
    except KeyboardInterrupt:
        raise
    except:
        return '', ''
    
    try:
        soup = BeautifulSoup(result, 'html.parser')
    except:
        return '', ''
    
    if soup.find('p', {"class": "err"}):
        return '', ''
    
    info = []
    rows = soup.find_all('tr')
    for row in rows:
        title_td = row.find('td', {"class": "title"})
        if title_td:
            td_elements = row.find_all('td')
            if len(td_elements) >= 2:
                value = td_elements[1].text.rstrip('\r')
                info.append(value)
    
    if len(info) >= 2:
        return info[0], info[1]
    elif len(info) == 1:
        return info[0], ''
    else:
        return '', ''


def __getserverinfo_thread(url: str) -> Tuple[str, str]:
    parsed = urlparse(url)
    domain = parsed.netloc if parsed.netloc else parsed.path.split("/")[0]
    
    if not domain:
        return '', ''
    
    target_url = f"https://aruljohn.com/webserver/{domain}"
    server = ''
    version = ''
    
    try:
        result = web.gethtml(target_url)
        if not result:
            return '', ''
    except:
        return '', ''
    
    try:
        soup = BeautifulSoup(result, 'html.parser')
    except:
        return '', ''
    
    if soup.find('p', {"class": "err"}):
        return '', ''
    
    info = []
    rows = soup.find_all('tr')
    for row in rows:
        title_td = row.find('td', {"class": "title"})
        if title_td:
            td_elements = row.find_all('td')
            if len(td_elements) >= 2:
                value = td_elements[1].text.rstrip('\r')
                info.append(value)
    
    if len(info) >= 2:
        return info[0], info[1]
    elif len(info) == 1:
        return info[0], ''
    else:
        return '', ''
