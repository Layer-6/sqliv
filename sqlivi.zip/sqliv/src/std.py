#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from colorama import Fore, Back, Style, init
init(autoreset=True)


class Color:
    RED = Fore.RED
    GREEN = Fore.GREEN
    YELLOW = Fore.YELLOW
    CYAN = Fore.CYAN
    MAGENTA = Fore.MAGENTA
    RESET = Fore.RESET

class Style:
    BRIGHT = Style.BRIGHT
    NORMAL = Style.NORMAL

import time
import json
from typing import List, Any, Optional, Union
from terminaltables import SingleTable


def stdin(message: str, params: List[str], upper: bool = False, lower: bool = False) -> str:
    symbol = f"{Color.MAGENTA}[OPT]{Color.RESET}"
    currentime = f"{Color.GREEN}[{time.strftime('%H:%M:%S')}]{Color.RESET}"
    
    option = input(f"{symbol} {currentime} {message}: ")
    
    if upper:
        option = option.upper()
    elif lower:
        option = option.lower()
    
    while option not in params:
        option = input(f"{symbol} {currentime} {message}: ")
        if upper:
            option = option.upper()
        elif lower:
            option = option.lower()
    
    return option


def stdout(message: str, end: str = "\n"):
    symbol = f"{Color.YELLOW}[MSG]{Color.RESET}"
    currentime = f"{Color.GREEN}[{time.strftime('%H:%M:%S')}]{Color.RESET}"
    print(f"{symbol} {currentime} {message}", end=end)


def stderr(message: str, end: str = "\n"):
    symbol = f"{Color.RED}[ERR]{Color.RESET}"
    currentime = f"{Color.GREEN}[{time.strftime('%H:%M:%S')}]{Color.RESET}"
    print(f"{symbol} {currentime} {message}", end=end)


def showsign(message: str):
    print(f"{Color.MAGENTA}{message}{Color.RESET}")


def dump(array: List[str], filename: str):
    with open(filename, 'w', encoding='utf-8') as output:
        for data in array:
            output.write(data + "\n")


def dumpjson(array: List[List[Any]], filename: str = 'result.json'):
    jsondata = {}
    for index, result in enumerate(array):
        jsondata[index] = {
            'url': str(result[0]),
            'db': str(result[1]) if len(result) > 1 else '',
            'server': str(result[2]) if len(result) > 2 else '',
            'lang': str(result[3]) if len(result) > 3 else ''
        }
    
    with open(filename, 'w', encoding='utf-8') as output:
        json.dump(jsondata, output, indent=4, ensure_ascii=False)


def printserverinfo(data: List[List[str]]):
    if not all(isinstance(item, list) for item in data):
        stderr("program err, data must be two dimensional array")
        return
    
    title = " DOMAINS "
    table_data = [["website", "server", "lang"]] + data
    table = SingleTable(table_data, title)
    print(table.table)


def normalprint(data: List[List[str]]):
    title = " VULNERABLE URLS "
    table_data = [["index", "url", "db"]]
    for index, url in enumerate(data):
        db = url[1] if len(url) > 1 else ''
        table_data.append([index + 1, url[0], db])
    
    table = SingleTable(table_data, title)
    print(table.table)


def fullprint(data: List[List[str]]):
    title = " VULNERABLE URLS "
    table_data = [["index", "url", "db", "server", "lang"]]
    
    for index, each in enumerate(data):
        url = each[0] if len(each) > 0 else ''
        db = each[1] if len(each) > 1 else ''
        server = each[2][:30] if len(each) > 2 else ''
        lang = each[3][:30] if len(each) > 3 else ''
        table_data.append([index + 1, url, db, server, lang])
    
    table = SingleTable(table_data, title)
    print(table.table)


def success(message: str):
    symbol = f"{Color.GREEN}[+]{Color.RESET}"
    currentime = f"{Color.GREEN}[{time.strftime('%H:%M:%S')}]{Color.RESET}"
    print(f"{symbol} {currentime} {message}")


def info(message: str):
    symbol = f"{Color.CYAN}[*]{Color.RESET}"
    currentime = f"{Color.GREEN}[{time.strftime('%H:%M:%S')}]{Color.RESET}"
    print(f"{symbol} {currentime} {message}")


def warning(message: str):
    symbol = f"{Color.YELLOW}[!]{Color.RESET}"
    currentime = f"{Color.GREEN}[{time.strftime('%H:%M:%S')}]{Color.RESET}"
    print(f"{symbol} {currentime} {message}")