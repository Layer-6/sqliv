#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
from typing import List, Optional
from urllib.error import HTTPError, URLError

from lib import bing
from lib import google
from lib import yahoo

bingsearch = bing.Bing()
yahoosearch = yahoo.Yahoo()


class Search:
    pass


class Google(Search):
    def search(self, query: str, pages: int = 10) -> List[str]:
        urls = []
        try:
            google_search = google.Google()
            urls = google_search.search(query, stop=pages)
        except HTTPError:
            sys.exit("[503] Service Unreachable")
        except URLError:
            sys.exit("[504] Gateway Timeout")
        except Exception:
            sys.exit("Unknown error occurred")
        return urls


class Bing(Search):
    def search(self, query: str, pages: int = 10) -> List[str]:
        try:
            return bingsearch.search(query, stop=pages)
        except HTTPError:
            sys.exit("[503] Service Unreachable")
        except URLError:
            sys.exit("[504] Gateway Timeout")
        except Exception:
            sys.exit("Unknown error occurred")


class Yahoo(Search):
    def search(self, query: str, pages: int = 1) -> List[str]:
        try:
            return yahoosearch.search(query, pages)
        except HTTPError:
            sys.exit("[503] Service Unreachable")
        except URLError:
            sys.exit("[504] Gateway Timeout")
        except Exception:
            sys.exit("Unknown error occurred")


def search_all(query: str, pages: int = 10) -> List[str]:
    results = []
    engines = [Google(), Bing(), Yahoo()]
    
    for engine in engines:
        try:
            urls = engine.search(query, pages)
            results.extend(urls)
        except:
            continue
    
    return list(set(results))
