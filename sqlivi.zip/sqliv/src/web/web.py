#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import time
import random
import gzip
from io import BytesIO
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from typing import Union, Tuple, Optional, Dict, Any

from src.web import useragents


def gethtml(url: str, lastURL: bool = False, timeout: int = 15, retries: int = 3) -> Union[str, Tuple[str, str], bool]:
    if not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    
    for attempt in range(retries):
        try:
            headers = useragents.get()
            headers.update({
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'DNT': '1',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            })
            
            request = Request(url, None, headers)
            
            with urlopen(request, timeout=timeout) as response:
                content = response.read()
                encoding = response.headers.get('Content-Encoding', '')
                
                if 'gzip' in encoding:
                    buffer = BytesIO(content)
                    content = gzip.GzipFile(fileobj=buffer).read()
                elif 'deflate' in encoding:
                    import zlib
                    content = zlib.decompress(content, -zlib.MAX_WBITS)
                
                html = content.decode('utf-8', errors='ignore')
                final_url = response.geturl()
                
                if lastURL:
                    return html, final_url
                return html
                
        except HTTPError as e:
            if e.code == 429:
                if attempt < retries - 1:
                    time.sleep(random.uniform(3, 10))
                    continue
            elif e.code == 500:
                try:
                    html = e.read().decode('utf-8', errors='ignore')
                    if lastURL:
                        return html, url
                    return html
                except:
                    pass
            elif attempt < retries - 1:
                time.sleep(random.uniform(1, 3))
                continue
                
        except URLError:
            if attempt < retries - 1:
                time.sleep(random.uniform(1, 3))
                continue
                
        except KeyboardInterrupt:
            raise
            
        except Exception:
            if attempt < retries - 1:
                time.sleep(random.uniform(1, 3))
                continue
    
    return False


def get_status(url: str, timeout: int = 10) -> Optional[int]:
    if not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    
    try:
        request = Request(url, headers=useragents.get())
        with urlopen(request, timeout=timeout) as response:
            return response.getcode()
    except:
        return None


def get_headers_only(url: str, timeout: int = 10) -> Optional[Dict[str, str]]:
    if not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    
    try:
        request = Request(url, headers=useragents.get(), method='HEAD')
        with urlopen(request, timeout=timeout) as response:
            return dict(response.headers)
    except:
        return None


def gethtml_parallel(urls: list, timeout: int = 15, retries: int = 2) -> Dict[str, Union[str, bool]]:
    results = {}
    for url in urls:
        results[url] = gethtml(url, timeout=timeout, retries=retries)
    return results
