#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import json
import time
import random
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse, urlencode
from typing import List, Optional, Dict, Any

class ReverseIP:
    def __init__(self, timeout: int = 15, retries: int = 3):
        self.timeout = timeout
        self.retries = retries
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]

    def _get_user_agent(self) -> str:
        return random.choice(self.user_agents)

    def reverseip(self, url: str) -> List[str]:
        parsed = urlparse(url)
        domain = parsed.netloc if parsed.netloc else parsed.path.split("/")[0]
        
        if not domain:
            return []

        api_url = "https://domains.yougetsignal.com/domains.php"
        
        for attempt in range(self.retries):
            try:
                headers = {
                    "User-Agent": self._get_user_agent(),
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "Accept": "application/json, text/javascript, */*",
                    "Referer": "https://www.yougetsignal.com/",
                    "X-Requested-With": "XMLHttpRequest"
                }

                post_data = urlencode({
                    'remoteAddress': domain,
                    'key': ''
                }).encode('utf-8')

                request = Request(api_url, data=post_data, headers=headers)
                
                with urlopen(request, timeout=self.timeout) as response:
                    result = response.read().decode('utf-8')
                    
                obj = json.loads(result)
                
                if obj.get("status") == "Success":
                    domains = []
                    for entry in obj.get("domainArray", []):
                        if entry and len(entry) > 0:
                            domain_name = entry[0]
                            if domain_name and domain_name not in domains:
                                domains.append(domain_name)
                    return domains
                    
                error_msg = obj.get("message", "Unknown error")
                sys.stderr.write(f"[ERR] {error_msg}\n")
                return []

            except HTTPError as e:
                if attempt < self.retries - 1:
                    time.sleep(random.uniform(1, 3))
                    continue
                sys.stderr.write(f"[{e.code}] HTTP error\n")
                
            except URLError as e:
                if attempt < self.retries - 1:
                    time.sleep(random.uniform(1, 3))
                    continue
                sys.stderr.write(f"URL error: {e.reason}\n")
                
            except json.JSONDecodeError:
                if attempt < self.retries - 1:
                    time.sleep(random.uniform(1, 3))
                    continue
                sys.stderr.write("Failed to parse JSON response\n")
                
            except Exception as e:
                if attempt < self.retries - 1:
                    time.sleep(random.uniform(1, 3))
                    continue
                sys.stderr.write(f"HTTP exception: {e}\n")

        return []

    def reverseip_bulk(self, urls: List[str]) -> Dict[str, List[str]]:
        results = {}
        for url in urls:
            try:
                domains = self.reverseip(url)
                if domains:
                    results[url] = domains
                    time.sleep(random.uniform(0.5, 1.5))
            except:
                continue
        return results

def reverseip(url: str) -> List[str]:
    """Convenience function for backward compatibility"""
    return ReverseIP().reverseip(url)
