#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
from typing import Tuple, Optional, Dict, List

sql_errors: Dict[str, List[str]] = {
    "MySQL": [
        r"SQL syntax.*MySQL",
        r"Warning.*mysql_.*",
        r"MySQL Query fail.*",
        r"SQL syntax.*MariaDB server",
        r"MySQL server version",
        r"Unknown column",
        r"Table '.*' doesn't exist"
    ],
    "PostgreSQL": [
        r"PostgreSQL.*ERROR",
        r"Warning.*\Wpg_.*",
        r"Warning.*PostgreSQL",
        r"invalid input syntax",
        r"ERROR:.*relation.*does not exist"
    ],
    "Microsoft SQL Server": [
        r"OLE DB.* SQL Server",
        r"(\W|\A)SQL Server.*Driver",
        r"Warning.*odbc_.*",
        r"Warning.*mssql_",
        r"Msg \d+, Level \d+, State \d+",
        r"Unclosed quotation mark after the character string",
        r"Microsoft OLE DB Provider for ODBC Drivers",
        r"Microsoft SQL Native Client",
        r"Server Error in '/.*' Application",
        r"System.Data.SqlClient.SqlException"
    ],
    "Microsoft Access": [
        r"Microsoft Access Driver",
        r"Access Database Engine",
        r"Microsoft JET Database Engine",
        r".*Syntax error.*query expression",
        r"Could not find file.*\.mdb",
        r"Microsoft Access.*Database Engine"
    ],
    "Oracle": [
        r"\bORA-[0-9]{4}",
        r"Oracle error",
        r"Warning.*oci_.*",
        r"Microsoft OLE DB Provider for Oracle",
        r"Oracle.*Driver",
        r"ORA-[0-9]{5}"
    ],
    "IBM DB2": [
        r"CLI Driver.*DB2",
        r"DB2 SQL error",
        r"com.ibm.db2",
        r"DB2 SQLSTATE"
    ],
    "SQLite": [
        r"SQLite/JDBCDriver",
        r"System.Data.SQLite.SQLiteException",
        r"SQLite3::",
        r"SQLite error",
        r"no such table"
    ],
    "Informix": [
        r"Warning.*ibase_.*",
        r"com.informix.jdbc",
        r"Informix.*Driver"
    ],
    "Sybase": [
        r"Warning.*sybase.*",
        r"Sybase message",
        r"com.sybase.jdbc"
    ],
    "Firebird": [
        r"firebird.*error",
        r"FBException"
    ],
    "Generic": [
        r"Unclosed quotation mark",
        r"Syntax error.*string",
        r"Data type mismatch"
    ]
}


def check(html: str) -> Tuple[bool, Optional[str]]:
    if not html:
        return False, None
    
    for db, errors in sql_errors.items():
        for error in errors:
            if re.compile(error, re.IGNORECASE).search(html):
                return True, db
    
    return False, None


def check_multiple(html: str) -> List[Tuple[str, str]]:
    if not html:
        return []
    
    found = []
    for db, errors in sql_errors.items():
        for error in errors:
            if re.compile(error, re.IGNORECASE).search(html):
                found.append((db, error))
                break
    
    return found


def add_error(db: str, pattern: str):
    if db not in sql_errors:
        sql_errors[db] = []
    sql_errors[db].append(pattern)


def get_database(html: str) -> Optional[str]:
    if not html:
        return None
    
    for db, errors in sql_errors.items():
        for error in errors:
            if re.compile(error, re.IGNORECASE).search(html):
                return db
    
    return None
