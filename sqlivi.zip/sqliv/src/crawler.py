#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import time
import random
import base64
import urllib.parse
from urllib.parse import urlparse, urljoin, parse_qs, unquote
from typing import List, Set, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
import warnings

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)


class Crawler:
    def __init__(self, depth: int = 3, timeout: int = 15, threads: int = 10, user_agent: Optional[str] = None):
        self.links: List[str] = []
        self.visited: Set[str] = set()
        self.depth = depth
        self.timeout = timeout
        self.threads = threads
        self.user_agent = user_agent or self._random_user_agent()
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.user_agent})
        self.base_domain: Optional[str] = None
        self._url_params_pattern = re.compile(r'\?.*=')
        self._ajax_patterns = [
            re.compile(r'\.ajax\([^)]*url:\s*["\']([^"\']+)["\']'),
            re.compile(r'\$\.get\(["\']([^"\']+)["\']'),
            re.compile(r'\$\.post\(["\']([^"\']+)["\']'),
            re.compile(r'fetch\(["\']([^"\']+)["\']'),
            re.compile(r'XMLHttpRequest.*\.open\(["\'][^"\']+["\'],\s*["\']([^"\']+)["\']'),
            re.compile(r'\.load\(["\']([^"\']+)["\']'),
        ]
        self._encoded_patterns = [
            (re.compile(r'[A-Za-z0-9+/=]{20,}'), self._decode_base64),
            (re.compile(r'%[0-9A-Fa-f]{2}'), self._decode_url),
            (re.compile(r'&#x[0-9A-Fa-f]+;'), self._decode_html_entities),
        ]

    def _random_user_agent(self) -> str:
        agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15'
        ]
        return random.choice(agents)

    def _decode_base64(self, text: str) -> str:
        try:
            decoded = base64.b64decode(text).decode('utf-8', errors='ignore')
            if 'http' in decoded:
                return decoded
        except:
            pass
        return text

    def _decode_url(self, text: str) -> str:
        try:
            return urllib.parse.unquote(text)
        except:
            return text

    def _decode_html_entities(self, text: str) -> str:
        try:
            import html
            return html.unescape(text)
        except:
            return text

    def _decode_content(self, content: str) -> str:
        for pattern, decoder in self._encoded_patterns:
            matches = pattern.findall(content)
            for match in matches:
                decoded = decoder(match)
                if decoded != match:
                    content = content.replace(match, decoded)
        return content

    def _extract_ajax_urls(self, content: str) -> List[str]:
        urls = []
        for pattern in self._ajax_patterns:
            matches = pattern.findall(content)
            for match in matches:
                if match.startswith('/') or match.startswith('http'):
                    urls.append(match)
        return urls

    def crawl(self, url: str) -> List[str]:
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        
        parsed = urlparse(url)
        self.base_domain = f"{parsed.scheme}://{parsed.netloc}"
        self.links = []
        self.visited = set()
        
        self._crawl_recursive(url, current_depth=0)
        
        final_links = []
        for link in self.links:
            if not link.startswith(('mailto:', 'javascript:', 'tel:')):
                final_links.append(link)
        
        return list(set(final_links))

    def _crawl_recursive(self, url: str, current_depth: int):
        if current_depth > self.depth:
            return
        if url in self.visited:
            return
        
        self.visited.add(url)
        
        try:
            response = self.session.get(url, timeout=self.timeout, allow_redirects=True)
            if response.status_code != 200:
                return
            content = response.text
        except:
            return

        content = self._decode_content(content)
        soup = BeautifulSoup(content, 'html.parser')

        for tag in soup.find_all(['a', 'link', 'area']):
            href = tag.get('href')
            if href:
                full_url = urljoin(url, href)
                if self._is_same_domain(full_url) and self._url_params_pattern.search(full_url):
                    self.links.append(full_url)
                if current_depth < self.depth:
                    self._crawl_recursive(full_url, current_depth + 1)

        for tag in soup.find_all(['img', 'script', 'iframe', 'frame', 'source']):
            src = tag.get('src')
            if src:
                full_url = urljoin(url, src)
                if self._is_same_domain(full_url) and self._url_params_pattern.search(full_url):
                    self.links.append(full_url)

        for form in soup.find_all('form'):
            action = form.get('action')
            if action:
                full_url = urljoin(url, action)
                if self._is_same_domain(full_url) and self._url_params_pattern.search(full_url):
                    self.links.append(full_url)
            
            inputs = form.find_all('input')
            if inputs and action:
                base_url = urljoin(url, action)
                params = []
                for inp in inputs:
                    name = inp.get('name')
                    if name:
                        params.append(f"{name}=test")
                if params:
                    full_url = f"{base_url}?{'&'.join(params)}"
                    self.links.append(full_url)

        for script in soup.find_all('script'):
            if script.string:
                js_content = script.string
                ajax_urls = self._extract_ajax_urls(js_content)
                for ajax_url in ajax_urls:
                    full_url = urljoin(url, ajax_url)
                    if self._is_same_domain(full_url) and self._url_params_pattern.search(full_url):
                        self.links.append(full_url)

        for meta in soup.find_all('meta'):
            content_attr = meta.get('content')
            if content_attr and 'url=' in content_attr:
                for part in content_attr.split('&'):
                    if part.startswith('url='):
                        meta_url = part.split('=')[1]
                        full_url = urljoin(url, meta_url)
                        if self._is_same_domain(full_url) and self._url_params_pattern.search(full_url):
                            self.links.append(full_url)

    def _is_same_domain(self, url: str) -> bool:
        try:
            parsed = urlparse(url)
            base = urlparse(self.base_domain)
            return parsed.netloc == base.netloc or parsed.netloc == ""
        except:
            return False

    def setoptions(self, depth: int = 3, timeout: int = 15, threads: int = 10, user_agent: Optional[str] = None):
        self.depth = depth
        self.timeout = timeout
        self.threads = threads
        if user_agent:
            self.user_agent = user_agent
            self.session.headers.update({"User-Agent": self.user_agent})
